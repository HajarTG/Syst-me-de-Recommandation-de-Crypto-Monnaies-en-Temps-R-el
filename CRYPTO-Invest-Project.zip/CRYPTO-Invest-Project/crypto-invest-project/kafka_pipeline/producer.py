from confluent_kafka import Producer
import json
import time
import requests
from datetime import datetime
import socket
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# Kafka configuration
producer = Producer({
    'bootstrap.servers': 'localhost:9092',
    'queue.buffering.max.messages': 1000000,
    'queue.buffering.max.ms': 500
})
topic = 'crypto_coingecko'

def delivery_report(err, msg):
    if err is not None:
        print(f"Delivery failed: {err}")
    else:
        print(f"Message delivered to {msg.topic()} [{msg.partition()}]")

def get_crypto_data():
    try:
        session = requests.Session()
        retries = Retry(
            total=5,
            backoff_factor=1,
            status_forcelist=[500, 502, 503, 504]
        )
        session.mount('https://', HTTPAdapter(max_retries=retries))

        for _ in range(3):
            try:
                response = session.get(
                    'https://api.coingecko.com/api/v3/coins/markets',
                    params={
                        'vs_currency': 'usd',
                        'order': 'market_cap_desc',
                        'per_page': 100,
                        'sparkline': False,
                        'price_change_percentage': '24h'
                    },
                    timeout=10
                )
                response.raise_for_status()
                return response.json()
            except socket.gaierror:
                print("DNS resolution failed, retrying...")
                time.sleep(1)
                continue
            except requests.exceptions.RequestException as e:
                print(f"Request failed: {e}")
                time.sleep(1)
                continue
        return None
    except Exception as e:
        print(f"Error fetching data: {str(e)}")
        return None

def main():
    print("Starting cryptocurrency data producer...")

    while True:
        try:
            data = get_crypto_data()
            if data:
                current_time = datetime.utcnow()

                for item in data:
                    message = {
                        'name': item['name'],
                        'symbol': item['symbol'].upper(),
                        'price_usd': item['current_price'],
                        'market_cap_usd': item['market_cap'],
                        'ingestion_time': current_time.isoformat()
                    }

                    producer.produce(
                        topic,
                        key=message['symbol'],
                        value=json.dumps(message),
                        callback=delivery_report
                    )

                print(f"Data batch sent at {current_time}")
                producer.flush()
            else:
                print("No data received from API")

            time.sleep(30)

        except Exception as e:
            print(f"Error in main loop: {str(e)}")
            time.sleep(5)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("Stopping producer...")
        producer.flush()
        print("Producer stopped.")

