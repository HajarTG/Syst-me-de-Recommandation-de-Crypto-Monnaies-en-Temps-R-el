from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col, current_timestamp
from pyspark.sql.types import StructType, StringType, DoubleType

spark = SparkSession.builder \
    .appName("CryptoAggregatorConsumer") \
    .config("spark.cassandra.connection.host", "cassandra") \
    .config("spark.cassandra.connection.port", "9042") \
    .config("spark.sql.streaming.checkpointLocation", "/tmp/spark_checkpoint_aggregator") \
    .getOrCreate()

schema = StructType() \
    .add("name", StringType()) \
    .add("symbol", StringType()) \
    .add("price_usd", DoubleType()) \
    .add("market_cap_usd", DoubleType())

df_raw = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "kafka:9092") \
    .option("subscribe", "crypto_coingecko,crypto_binance,crypto_coinmarketcap") \
    .option("startingOffsets", "latest") \
    .load()

parsed = df_raw.selectExpr("CAST(value AS STRING) as json_str") \
    .select(from_json(col("json_str"), schema).alias("data")) \
    .select("data.*") \
    .filter(col("symbol").isNotNull() & col("price_usd").isNotNull())

def write_to_cassandra(df, epoch_id):
    df = df.withColumn("ingestion_time", current_timestamp())
    df.write \
        .format("org.apache.spark.sql.cassandra") \
        .mode("append") \
        .option("keyspace", "crypto_db") \
        .option("table", "aggregator") \
        .save()

query = parsed.writeStream \
    .foreachBatch(write_to_cassandra) \
    .outputMode("append") \
    .start()

query.awaitTermination()

