import sys
import subprocess
import time
import os

# Get the project root directory
project_root = os.path.dirname(os.path.abspath(__file__))
python_path = sys.executable  # récupère le python actif (celui de l'env)

print("✅ Starting Kafka producer...")
subprocess.run([python_path, os.path.join(project_root, "data", "aggregator.py")])

time.sleep(5)

print("✅ Starting Spark consumer (Kafka → Cassandra)...")
consumer = subprocess.Popen([
    "docker", "exec", "-i", "crypto-invest-project-spark-master-1",
    "spark-submit",
    "--packages",
    "org.apache.spark:spark-sql-kafka-0-10_2.12:3.4.1,com.datastax.spark:spark-cassandra-connector_2.12:3.4.1",
    r"C:\Users\Lenovo\Downloads\crypto-invest-project.hiba\crypto-invest-project\kafka_pipeline\consumer_spark.py"
])
time.sleep(10)

print("✅ Starting Spark processing (Cassandra transformation)...")
subprocess.run([
    "docker", "exec", "-i", "crypto-invest-project-spark-master-1",
    "spark-submit",
    "--packages",
    "com.datastax.spark:spark-cassandra-connector_2.12:3.4.1",
    r"C:\Users\Lenovo\Downloads\crypto-invest-project.hiba\crypto-invest-project\spark\spark_processing.py"
])
time.sleep(5)

print("✅ Running LSTM prediction on processed data...")
subprocess.run([
    "jupyter", "nbconvert", "--to", "script",
    r"C:\Users\Lenovo\Downloads\crypto-invest-project.hiba\crypto-invest-project\ma3ert3awed.py"
])

consumer.wait()
