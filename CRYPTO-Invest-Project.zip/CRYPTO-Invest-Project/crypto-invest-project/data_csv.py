import requests
import pandas as pd
import time

def fetch_coingecko(pages=5):
    all_data = []
    for page in range(1, pages + 1):
        url = "https://api.coingecko.com/api/v3/coins/markets"
        params = {
            'vs_currency': 'usd',
            'order': 'market_cap_desc',
            'per_page': 100,
            'page': page,
            'price_change_percentage': '1h,24h,7d,30d'
        }
        try:
            response = requests.get(url, params=params)
            data = response.json()
            for coin in data:
                all_data.append({
                    'source': 'coingecko',
                    'id': coin['id'],
                    'symbol': coin['symbol'],
                    '1h': coin['price_change_percentage_1h_in_currency'],
                    '24h': coin['price_change_percentage_24h_in_currency'],
                    '7d': coin['price_change_percentage_7d_in_currency'],
                    '30d': coin.get('price_change_percentage_30d_in_currency', 0),
                    'volume': coin['total_volume'],
                    'market_cap': coin['market_cap'],
                    'fdv': coin.get('fully_diluted_valuation', 0),
                })
            time.sleep(1)
        except Exception as e:
            print(f"Erreur CoinGecko page {page} : {e}")
    return all_data

def fetch_binance(limit=500):
    url = "https://api.binance.com/api/v3/ticker/24hr"
    try:
        response = requests.get(url)
        data = response.json()
        filtered = []
        for coin in data[:limit]:
            filtered.append({
                'source': 'binance',
                'id': None,
                'symbol': coin['symbol'],
                '1h': None,
                '24h': float(coin.get('priceChangePercent', 0)),
                '7d': None,
                '30d': None,
                'volume': float(coin.get('quoteVolume', 0)),
                'market_cap': None,
                'fdv': None,
            })
        return filtered
    except Exception as e:
        print(f"Erreur Binance : {e}")
        return []

def collect_combined_data():
    cg_data = fetch_coingecko(pages=5)
    binance_data = fetch_binance(limit=500)
    all_data = cg_data + binance_data

    df = pd.DataFrame(all_data)

    # Remplissage + calculs uniquement pour CoinGecko
    df['fdv'] = df['fdv'].fillna(0)
    df['market_cap'] = df['market_cap'].fillna(0)
    df['mc_fdv_ratio'] = df['market_cap'] / df['fdv'].replace(0, 1)
    df['30d'] = df['30d'].fillna(0)

    # Label uniquement pour CoinGecko
    df['label'] = df.apply(lambda row: 1 if row['source'] == 'coingecko' and row['30d'] > 0 else None, axis=1)

    df.to_csv("data/backup_data.csv", index=False)
    print(f"✅ Données combinées enregistrées ({len(df)} lignes)")

collect_combined_data()





