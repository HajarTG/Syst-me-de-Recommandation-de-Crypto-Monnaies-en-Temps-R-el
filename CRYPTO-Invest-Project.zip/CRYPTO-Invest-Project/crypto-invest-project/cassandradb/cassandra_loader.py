import json
from cassandra.cluster import Cluster
from cassandra.query import SimpleStatement
from confluent_kafka import Producer

# Configuration
cassandra_host = "localhost"
cassandra_keyspace = "crypto_db"
cassandra_table = "cryptos"
data_file = "crypto_data.json"  # can be .csv if needed
kafka_topic = "crypto_topic"
kafka_broker = "localhost:9092"

# Kafka Producer configuration
producer = Producer({'bootstrap.servers': kafka_broker})

# Connect to Cassandra
cluster = Cluster([cassandra_host])
session = cluster.connect(cassandra_keyspace)

# Load and insert JSON data into Cassandra
with open(data_file, "r", encoding="utf-8") as f:
    data = json.load(f)
    if isinstance(data, list):
        for item in data:
            # Insert into Cassandra
            insert_query = SimpleStatement("""
                INSERT INTO cryptos (id, name, symbol, price_usd, market_cap_usd)
                VALUES (uuid(), %(name)s, %(symbol)s, %(price_usd)s, %(market_cap_usd)s)
            """)
            session.execute(insert_query, item)
            
            # Send to Kafka
            producer.produce(kafka_topic, value=json.dumps(item))
            producer.flush()  # Ensure message is sent to Kafka

    else:
        # Insert a single item into Cassandra
        insert_query = SimpleStatement("""
            INSERT INTO cryptos (id, name, symbol, price_usd, market_cap_usd)
            VALUES (uuid(), %(name)s, %(symbol)s, %(price_usd)s, %(market_cap_usd)s)
        """)
        session.execute(insert_query, data)
        
        # Send to Kafka
        producer.produce(kafka_topic, value=json.dumps(data))
        producer.flush()  # Ensure message is sent to Kafka

print(f"Data inserted into Cassandra and sent to Kafka topic '{kafka_topic}'")

