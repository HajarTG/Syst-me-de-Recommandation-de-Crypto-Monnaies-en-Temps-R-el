import time
import requests
import json
from kafka import KafkaProducer

# Configuration Kafka Producer
producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

# --- Fonctions de récupération des données ---

def fetch_coingecko():
    url = "https://api.coingecko.com/api/v3/coins/markets"
    params = {
        'vs_currency': 'usd',
        'order': 'market_cap_desc',
        'per_page': 100,
        'page': 1,
        'price_change_percentage': '1h,24h,7d,30d'
    }
    response = requests.get(url, params=params)
    response.raise_for_status()
    return response.json()

def fetch_binance():
    url = "https://api.binance.com/api/v3/ticker/24hr"
    response = requests.get(url)
    response.raise_for_status()
    return response.json()

def fetch_coinmarketcap(api_key):
    headers = {'X-CMC_PRO_API_KEY': api_key}
    url = 'https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest'
    params = {'start': '1', 'limit': '100', 'convert': 'USD'}
    response = requests.get(url, headers=headers, params=params)
    response.raise_for_status()
    return response.json()['data']

# --- Fonction principale ---

def main():
    coinmarketcap_api_key = 'cf465fef-54a4-460b-87b4-07bbb7c4177c'
    
    while True:
        try:
            print("🔄 Récupération des données...")
            cg_data = fetch_coingecko()
            binance_data = fetch_binance()
            cmc_data = fetch_coinmarketcap(coinmarketcap_api_key)

            # Envoi dans le topic crypto_coingecko
            for coin in cg_data:
                filtered = {
                    'name': coin.get('name'),
                    'symbol': coin.get('symbol'),
                    'price_usd': coin.get('current_price'),
                    'market_cap_usd': coin.get('market_cap')
                }
                producer.send('crypto_coingecko', value=filtered)
                print(f"[Kafka][crypto_coingecko] {filtered['symbol']} envoyé")

            # Envoi dans le topic crypto_binance
            for coin in binance_data:
                filtered = {
                    'symbol': coin.get('symbol'),
                    'price_usd': float(coin.get('lastPrice', 0)),
                    'market_cap_usd': float(coin.get('quoteVolume', 0)),
                    'name': None
                }
                producer.send('crypto_binance', value=filtered)
                print(f"[Kafka][crypto_binance] {filtered['symbol']} envoyé")

            # Envoi dans le topic crypto_coinmarketcap
            for coin in cmc_data:
                filtered = {
                    'name': coin.get('name'),
                    'symbol': coin.get('symbol'),
                    'price_usd': coin['quote']['USD'].get('price'),
                    'market_cap_usd': coin['quote']['USD'].get('market_cap')
                }
                producer.send('crypto_coinmarketcap', value=filtered)
                print(f"[Kafka][crypto_coinmarketcap] {filtered['symbol']} envoyé")

            producer.flush()
            print("✅ Tous les messages ont été envoyés et flushés avec succès.\n")
            time.sleep(60)  # pause d'une minute

        except Exception as e:
            print(f"❌ Erreur lors de la récupération ou de l'envoi : {e}")
            time.sleep(60)

if __name__ == "__main__":
    main()
