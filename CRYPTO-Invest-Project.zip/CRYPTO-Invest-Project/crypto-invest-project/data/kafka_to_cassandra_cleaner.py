from kafka import KafkaConsumer
import json
import pandas as pd
from cassandra.cluster import Cluster

# Connexion à Cassandra
cluster = Cluster(['127.0.0.1'])  # à adapter si besoin
session = cluster.connect('crypto_keyspace')  # à adapter selon ton keyspace
session.execute("""
    CREATE TABLE IF NOT EXISTS crypto_data (
        id TEXT,
        symbol TEXT,
        h1 FLOAT,
        h24 FLOAT,
        d7 FLOAT,
        d30 FLOAT,
        volume FLOAT,
        market_cap FLOAT,
        fdv FLOAT,
        mc_fdv_ratio FLOAT,
        prediction INT,
        PRIMARY KEY (id)
    )
""")

# Connexion au topic Kafka
consumer = KafkaConsumer(
    'crypto_topic',
    bootstrap_servers='localhost:9092',
    value_deserializer=lambda m: json.loads(m.decode('utf-8'))
)

# Fonction de nettoyage et insertion
for msg in consumer:
    try:
        data = msg.value

        # Convertir en DataFrame pour faciliter les vérifications
        df = pd.DataFrame([data])

        # Vérifier colonnes nécessaires
        required = ['id', 'symbol', '1h', '24h', '7d', '30d', 'volume', 'market_cap', 'fdv', 'mc_fdv_ratio']
        if not all(col in df.columns for col in required):
            continue

        # Convertir en numérique
        for col in required[2:]:
            df[col] = pd.to_numeric(df[col], errors='coerce')

        df = df.dropna()

        if df.empty:
            continue

        row = df.iloc[0]

        # Appliquer règles pour prédiction
        prediction = int(
            row['7d'] > 0 and
            row['24h'] > 0 and
            row['volume'] > 1_000_000 and  # valeur seuil arbitraire
            row['market_cap'] > 10_000_000 and
            row['mc_fdv_ratio'] < 1
        )

        # Insérer dans Cassandra
        session.execute("""
            INSERT INTO crypto_data (id, symbol, h1, h24, d7, d30, volume, market_cap, fdv, mc_fdv_ratio, prediction)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            row['id'], row['symbol'], row['1h'], row['24h'], row['7d'], row['30d'],
            row['volume'], row['market_cap'], row['fdv'], row['mc_fdv_ratio'], prediction
        ))

        print(f"✅ Donnée insérée pour {row['symbol']}")

    except Exception as e:
        print(f"❌ Erreur : {e}")
