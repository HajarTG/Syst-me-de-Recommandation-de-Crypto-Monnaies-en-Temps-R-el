from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json
from pyspark.sql.types import StructType, StringType, FloatType

# Create Spark session with Cassandra config
spark = SparkSession.builder \
    .appName("CryptoStream") \
    .config("spark.cassandra.connection.host", "127.0.0.1") \
    .config("spark.jars.packages", "org.apache.spark:spark-sql-kafka-0-10_2.12:3.4.1,com.datastax.spark:spark-cassandra-connector_2.12:3.4.1") \
    .config("spark.sql.streaming.checkpointLocation", "/tmp/checkpoints/crypto") \
    .getOrCreate()

# Define schema for incoming JSON data
schema = StructType() \
    .add("name", StringType()) \
    .add("symbol", StringType()) \
    .add("current_price", FloatType()) \
    .add("price_change_percentage_24h", FloatType()) \
    .add("price_change_percentage_7d", FloatType()) \
    .add("price_change_percentage_30d", FloatType()) \
    .add("market_cap", FloatType()) \
    .add("fdv", FloatType()) \
    .add("volume_24h", FloatType()) \
    .add("market_cap_to_fdv_ratio", FloatType())

# Read the Kafka stream
df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "crypto_coingecko") \
    .option("startingOffsets", "latest") \
    .load()

# Convert Kafka message (bytes) into structured JSON
json_df = df.selectExpr("CAST(value AS STRING)")
parsed_df = json_df.select(from_json("value", schema).alias("data")).select("data.*")

# Write data to Cassandra in append mode
query = parsed_df.writeStream \
    .format("org.apache.spark.sql.cassandra") \
    .option("keyspace", "crypto_db") \
    .option("table", "cryptos") \
    .option("checkpointLocation", "/tmp/checkpoints/crypto") \
    .outputMode("append") \
    .start()

# Await termination to keep the stream running
query.awaitTermination()
